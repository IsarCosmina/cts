package ro.ase.cts.Isar.Cosmina.Grupa1073.DesignPatterns;

public interface IAutocamion {
	
	public void tipInstalatieAC(String tipAC);
	public void afisareTipAC();
	
}
