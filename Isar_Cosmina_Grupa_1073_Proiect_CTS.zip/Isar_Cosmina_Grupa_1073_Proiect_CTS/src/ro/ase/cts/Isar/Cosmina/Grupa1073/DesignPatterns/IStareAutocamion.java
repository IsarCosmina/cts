package ro.ase.cts.Isar.Cosmina.Grupa1073.DesignPatterns;

public interface IStareAutocamion {
	
	public abstract void afiseazaInfoStare(String text);
	
}
