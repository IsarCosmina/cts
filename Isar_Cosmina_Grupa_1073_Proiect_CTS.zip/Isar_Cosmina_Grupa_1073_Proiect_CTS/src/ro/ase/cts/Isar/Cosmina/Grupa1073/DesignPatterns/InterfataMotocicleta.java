package ro.ase.cts.Isar.Cosmina.Grupa1073.DesignPatterns;

public abstract class InterfataMotocicleta extends Motocicleta{

	public InterfataMotocicleta(String marca, String model) {
		super(marca, model);
	}

	public abstract String afiseazaImbunatatiriMotocicleta();
	
}
