package ro.ase.cts.Isar.Cosmina.Grupa1073.DesignPatterns;

public class FaruriCuXenon {
	
	protected boolean areFaruriCuXenon = true;
	
	public void adaugaFaruriCuXenon() {
		this.areFaruriCuXenon = true;
	}
	
	public void eliminaFaruriCuXenon() {
		this.areFaruriCuXenon = false;
	}

}
