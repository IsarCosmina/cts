package ro.ase.cts.Isar.Cosmina.Grupa1073.DesignPatterns;

public interface IAutoturism {

	public void tipClimatizare(String tipClimatizare);
	public void afisareTipClimatizare();
	
}
